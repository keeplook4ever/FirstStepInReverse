Nothing to see here :)

Reach out to me at dinezh.shetty@gmail.com in case you need hints on detecting any of the vulnerabilites in this application.
